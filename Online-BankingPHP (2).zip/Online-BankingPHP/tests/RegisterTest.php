<?php
use PHPUnit\Framework\TestCase;

// Dummy register validation function
function validateRegister($name, $email, $password)
{
    if (empty($name) || empty($email) || empty($password)) {
        return false;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    return true;
}

class RegisterTest extends TestCase
{
    public function testRegisterWithValidData()
    {
        $this->assertTrue(validateRegister("Ali", "ali@gmail.com", "pass123"));
    }

    public function testRegisterWithInvalidEmail()
    {
        $this->assertFalse(validateRegister("Ali", "wrong-email", "pass123"));
    }

    public function testRegisterWithEmptyFields()
    {
        $this->assertFalse(validateRegister("", "", ""));
    }
}
