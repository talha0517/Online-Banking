<?php
use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    public function testValidLogin()
    {
        $this->assertTrue(true);
    }

    public function testInvalidLogin()
    {
        $this->assertFalse(false);
    }
}
