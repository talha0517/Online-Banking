<?php

function validateLogin($username, $password) {
    if (empty($username) || empty($password)) {
        return false;
    }
    return true;
}

function validateRegister($name, $email, $password) {
    if (empty($name) || empty($email) || empty($password)) {
        return false;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    return true;
}
