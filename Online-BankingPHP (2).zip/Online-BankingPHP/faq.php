<?php include 'header.php'; ?>

<style>
.chatbox {
    width: 60%;
    margin: 30px auto;
    border: 1px solid #ccc;
    padding: 15px;
    border-radius: 8px;
    background: #f9f9f9;
}
.bot, .user {
    margin: 10px 0;
}
.bot {
    color: #000;
}
.user {
    text-align: right;
    color: #0066cc;
}
.question-btn {
    display: block;
    margin: 5px 0;
    padding: 8px;
    background: #0066cc;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}
.question-btn:hover {
    background: #004c99;
}
</style>

<div class="chatbox">
    <h3>Bank Help Bot 🤖</h3>

    <div id="chat">
        <div class="bot">Hello! How can I help you today?</div>
    </div>

    <hr>

    <!-- Predefined Questions -->
    <button class="question-btn" onclick="askQuestion('password')">
        How can I reset my password?
    </button>

    <button class="question-btn" onclick="askQuestion('transfer')">
        How can I transfer funds?
    </button>

    <button class="question-btn" onclick="askQuestion('security')">
        Is online banking secure?
    </button>

    <button class="question-btn" onclick="askQuestion('support')">
        How can I contact customer support?
    </button>
</div>

<script>
function askQuestion(type) {
    let chat = document.getElementById("chat");

    let answers = {
        password: "You can reset your password using the 'Forgot Password' option on the login page.",
        transfer: "Login to your account and go to the Fund Transfer section.",
        security: "Yes, online banking is secured using OTP and session-based authentication.",
        support: "You can contact customer support via the Contact Us page."
    };

    // show user question
    chat.innerHTML += `<div class="user">You asked: ${event.target.innerText}</div>`;

    // show bot answer
    chat.innerHTML += `<div class="bot">Bot: ${answers[type]}</div>`;

    chat.scrollTop = chat.scrollHeight;
}
</script>

<?php include 'footer.php'; ?>
